// const [notification, setNotification] = useState({show: false, message: ""});

// const handleShowNotification = (message) => {
//     if (notificationTimeoutRef.current) {
//         clearTimeout(notificationTimeoutRef.current);
//     }
//     setNotification({show: true, message: message});
//
//     notificationTimeoutRef.current = setTimeout(() => {
//         setNotification({show: false, message: ""});
//         notificationTimeoutRef.current = null;
//     }, 2500)
// };

// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faMessage } from '@fortawesome/free-solid-svg-icons';