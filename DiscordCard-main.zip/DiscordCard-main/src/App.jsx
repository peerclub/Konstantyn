import React from 'react';
import UserProfile from './Profile.jsx';

const App = () => {
    return (
        <div className="container">
            <UserProfile/>
        </div>
    );
};

export default App;