# DiscordCard
Beautiful responsive business card in Discord style with custom data config on ReactJS
